AnimatedExpandableListView
==========================

An extendable, flexible ExpandableListView widget that supports animations.

Here is a video of the example, showcasing the robustness of the widget:

[![Alt text for your video](http://img.youtube.com/vi/J7rcFRKvpyY/0.jpg)](http://www.youtube.com/watch?v=J7rcFRKvpyY)

This project is dedicated to <strong>J Withey</strong> for giving me the motivation to write and release this source.
